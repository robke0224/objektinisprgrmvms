var searchData=
[
  ['generaterandomdata_0',['generateRandomData',['../student_8cpp.html#a14edffb8f2f065d9e18983f3f647462c',1,'generateRandomData(vector&lt; Student &gt; &amp;students, double hw):&#160;student.cpp'],['../student_8h.html#a14edffb8f2f065d9e18983f3f647462c',1,'generateRandomData(vector&lt; Student &gt; &amp;students, double hw):&#160;student.cpp']]],
  ['generaterandomgrades_1',['generateRandomGrades',['../student_8cpp.html#a3b103a376cef9e3f8339c196243f70a2',1,'generateRandomGrades(vector&lt; Student &gt; &amp;students, double hw):&#160;student.cpp'],['../student_8h.html#a3b103a376cef9e3f8339c196243f70a2',1,'generateRandomGrades(vector&lt; Student &gt; &amp;students, double hw):&#160;student.cpp']]],
  ['generaterandomnumber_2',['generateRandomNumber',['../student_8cpp.html#a8738fde2cefb820cd40c39cd0862ad2c',1,'generateRandomNumber(int min, int max):&#160;student.cpp'],['../student_8h.html#a8738fde2cefb820cd40c39cd0862ad2c',1,'generateRandomNumber(int min, int max):&#160;student.cpp']]],
  ['getexamresult_3',['getExamResult',['../class_student.html#a700fc566d4c6eb5edab6d278621204a3',1,'Student']]],
  ['getfinalavg_4',['getFinalAvg',['../class_student.html#a0f38908b6988e47f3c28d297459db3a3',1,'Student']]],
  ['getfinalmedian_5',['getFinalMedian',['../class_student.html#afd57f79f99ff9f35ecd3692eff118b46',1,'Student']]],
  ['getgrades_6',['getGrades',['../class_student.html#ab0fecfc0aab3ae7ceee626214a9a712c',1,'Student']]],
  ['getname_7',['getName',['../class_zmogus.html#a94f1670c7539cdaf4fa93cd8ccfc30f6',1,'Zmogus::getName()'],['../class_student.html#a2249ce4a1cc43d2a287351b43586190c',1,'Student::getName() const override']]],
  ['getsinglegrade_8',['getSingleGrade',['../class_student.html#ab6feb127b11eda23a5bb5690a25d1de3',1,'Student']]],
  ['getsurname_9',['getSurname',['../class_zmogus.html#a86d0927f1406c0668d46d5822a8658af',1,'Zmogus::getSurname()'],['../class_student.html#a847776f743684c63115c7f28828646ac',1,'Student::getSurname()']]]
];
