var searchData=
[
  ['enterdatamanually_0',['enterDataManually',['../student_8cpp.html#a2b915205fc37ea710dc6a131f72cc8f3',1,'enterDataManually(vector&lt; Student &gt; &amp;students, double hw):&#160;student.cpp'],['../student_8h.html#a2b915205fc37ea710dc6a131f72cc8f3',1,'enterDataManually(vector&lt; Student &gt; &amp;students, double hw):&#160;student.cpp']]]
];
