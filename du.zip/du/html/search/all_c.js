var searchData=
[
  ['testas_0',['testas',['../student_8cpp.html#a3ec92fd06cd5803bf3f1ad974518a284',1,'testas():&#160;student.cpp'],['../student_8h.html#a3ec92fd06cd5803bf3f1ad974518a284',1,'testas():&#160;student.cpp']]],
  ['testavimorezultatai_1',['testavimoRezultatai',['../student_8cpp.html#a4af28d7e5a1271cb17323ee0bad96e3b',1,'student.cpp']]]
];
