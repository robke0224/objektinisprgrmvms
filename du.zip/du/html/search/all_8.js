var searchData=
[
  ['name_0',['name',['../class_zmogus.html#a07bbe3ec35694144ecca725959cfaa44',1,'Zmogus']]],
  ['nuskaitymas_1',['Nuskaitymas',['../student_8cpp.html#ac484a8b7beae5d5dbf804bfcccf9b49d',1,'Nuskaitymas(const std::string &amp;failo_pavadinimas, std::vector&lt; Student &gt; &amp;students, int studentukiekis):&#160;student.cpp'],['../student_8h.html#ac484a8b7beae5d5dbf804bfcccf9b49d',1,'Nuskaitymas(const std::string &amp;failo_pavadinimas, std::vector&lt; Student &gt; &amp;students, int studentukiekis):&#160;student.cpp']]]
];
