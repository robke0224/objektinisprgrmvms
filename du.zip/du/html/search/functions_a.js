var searchData=
[
  ['setexamresult_0',['setExamResult',['../class_student.html#a953596ab8e46169e22d951f2597aec36',1,'Student']]],
  ['setfinalavg_1',['setFinalAvg',['../class_student.html#adb9c45580c1f3193156e2e3ff04f2628',1,'Student']]],
  ['setfinalmedian_2',['setFinalMedian',['../class_student.html#a0944eda11fae5430ec536d9949a0163e',1,'Student']]],
  ['setgrades_3',['setGrades',['../class_student.html#a641628ff3a767110a6a5eb9b9ca80844',1,'Student']]],
  ['setname_4',['setName',['../class_zmogus.html#a83fc452f091f6a8eec2ed2992c8cf977',1,'Zmogus::setName()'],['../class_student.html#a56f92191fed01e809ba2a57f92058adb',1,'Student::setName(const string &amp;vardas) override']]],
  ['setsinglegrade_5',['setSingleGrade',['../class_student.html#a0de678486a4c13dad36fb3087f3fcb02',1,'Student']]],
  ['setsurname_6',['setSurname',['../class_zmogus.html#ac06f7453d236aeef825126416b28ad55',1,'Zmogus::setSurname()'],['../class_student.html#a5b18ee52f8939e99d51fedaf7d55a041',1,'Student::setSurname()']]],
  ['skaiciuotividurki_7',['skaiciuotiVidurki',['../student_8cpp.html#ae09871f7af0a597e8f6c3b5ce11f4490',1,'skaiciuotiVidurki(const std::vector&lt; int &gt; &amp;pazymiai):&#160;student.cpp'],['../student_8h.html#ae09871f7af0a597e8f6c3b5ce11f4490',1,'skaiciuotiVidurki(const std::vector&lt; int &gt; &amp;pazymiai):&#160;student.cpp']]],
  ['student_8',['Student',['../class_student.html#af9168cedbfa5565cf0b20c1a9d3f5c9d',1,'Student']]]
];
