var searchData=
[
  ['name_0',['name',['../class_zmogus.html#a07bbe3ec35694144ecca725959cfaa44',1,'Zmogus']]]
];
