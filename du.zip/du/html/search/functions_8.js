var searchData=
[
  ['nuskaitymas_0',['Nuskaitymas',['../student_8cpp.html#ac484a8b7beae5d5dbf804bfcccf9b49d',1,'Nuskaitymas(const std::string &amp;failo_pavadinimas, std::vector&lt; Student &gt; &amp;students, int studentukiekis):&#160;student.cpp'],['../student_8h.html#ac484a8b7beae5d5dbf804bfcccf9b49d',1,'Nuskaitymas(const std::string &amp;failo_pavadinimas, std::vector&lt; Student &gt; &amp;students, int studentukiekis):&#160;student.cpp']]]
];
