var searchData=
[
  ['surname_0',['surname',['../class_zmogus.html#a3c1523956681968e2f0ed0477d5ef2d6',1,'Zmogus']]]
];
