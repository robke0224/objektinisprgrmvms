var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../class_student.html#adcabc19a4ec95cb8309ea542ccd5710d',1,'Student']]],
  ['operator_3e_3e_1',['operator&gt;&gt;',['../class_student.html#a46880ce43d618a4d5e2ef63a6b027664',1,'Student']]]
];
