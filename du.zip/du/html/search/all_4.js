var searchData=
[
  ['failugeneravimas_0',['failuGeneravimas',['../student_8cpp.html#a7ad92767adc5724c5c215d8f5db3c27a',1,'failuGeneravimas(int studentu_kiekis, const std::string &amp;failo_pavadinimas):&#160;student.cpp'],['../student_8h.html#a7ad92767adc5724c5c215d8f5db3c27a',1,'failuGeneravimas(int studentu_kiekis, const std::string &amp;failo_pavadinimas):&#160;student.cpp']]]
];
