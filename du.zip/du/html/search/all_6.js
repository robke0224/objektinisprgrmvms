var searchData=
[
  ['laikoskirtumas_0',['LaikoSkirtumas',['../student_8cpp.html#a9225ccbe3712e7920e03c6200ad6c064',1,'LaikoSkirtumas(const std::chrono::steady_clock::time_point &amp;pradzia, const std::chrono::steady_clock::time_point &amp;pabaiga):&#160;student.cpp'],['../student_8h.html#a9225ccbe3712e7920e03c6200ad6c064',1,'LaikoSkirtumas(const std::chrono::steady_clock::time_point &amp;pradzia, const std::chrono::steady_clock::time_point &amp;pabaiga):&#160;student.cpp']]],
  ['lygintipagalvidurki_1',['lygintiPagalVidurki',['../student_8cpp.html#a54e7f31d30437d86acf6195e93fb1d04',1,'lygintiPagalVidurki(const Student &amp;a, const Student &amp;b):&#160;student.cpp'],['../student_8h.html#a54e7f31d30437d86acf6195e93fb1d04',1,'lygintiPagalVidurki(const Student &amp;a, const Student &amp;b):&#160;student.cpp']]]
];
