var searchData=
[
  ['argerasstudentas_0',['arGerasStudentas',['../student_8cpp.html#a5ed52ffe70dd2be465d09533ce33fa9c',1,'arGerasStudentas(const Student &amp;student):&#160;student.cpp'],['../student_8h.html#a5ed52ffe70dd2be465d09533ce33fa9c',1,'arGerasStudentas(const Student &amp;student):&#160;student.cpp']]]
];
