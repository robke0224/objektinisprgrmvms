var searchData=
[
  ['nuskaitymas_0',['Nuskaitymas',['../student_8h.html#a3fef6b0b89373ffccafd02494c7ac67d',1,'student.cpp']]]
];
