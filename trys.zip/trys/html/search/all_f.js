var searchData=
[
  ['testas_0',['testas',['../student_8h.html#a3ec92fd06cd5803bf3f1ad974518a284',1,'student.cpp']]],
  ['testcustomvectorperformance_1',['testCustomVectorPerformance',['../student_8h.html#a3704b22f1a107d39f499fd8c88e90053',1,'student.cpp']]],
  ['teststdvectorperformance_2',['testStdVectorPerformance',['../student_8h.html#a7952aa768db2d123908c894e1a6ef758',1,'student.cpp']]]
];
