var searchData=
[
  ['readdatafromfile_0',['readDataFromFile',['../student_8h.html#ae2ae9f40dc41328f4ef01b5c4dd18627',1,'student.cpp']]],
  ['reserve_1',['reserve',['../class_vector.html#ac769dc5caf435551a9911f1358a7397d',1,'Vector']]],
  ['resize_2',['resize',['../class_vector.html#ade16f6d123b4fc1f372caac4a0eec16c',1,'Vector::resize(size_type sz)'],['../class_vector.html#abd80bbc42c16b6ddcd64dadcf4368c41',1,'Vector::resize(size_type sz, const value_type &amp;value)']]],
  ['rusiuoja_5fir_5fraso_5ffailus_3',['rusiuoja_ir_raso_failus',['../student_8h.html#aae15b7e8e6944eeb0777809dbb9ae33c',1,'student.cpp']]]
];
