var searchData=
[
  ['reference_0',['reference',['../class_vector.html#aacab8f5d93fda39cbdf810e3440d1c29',1,'Vector']]]
];
