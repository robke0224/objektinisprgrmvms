var searchData=
[
  ['setexamresult_0',['setExamResult',['../class_student.html#a953596ab8e46169e22d951f2597aec36',1,'Student']]],
  ['setfinalavg_1',['setFinalAvg',['../class_student.html#adb9c45580c1f3193156e2e3ff04f2628',1,'Student']]],
  ['setfinalmedian_2',['setFinalMedian',['../class_student.html#a0944eda11fae5430ec536d9949a0163e',1,'Student']]],
  ['setgrades_3',['setGrades',['../class_student.html#a008136c9b1595fcf3075bb2c18915450',1,'Student']]],
  ['setname_4',['setName',['../class_zmogus.html#a83fc452f091f6a8eec2ed2992c8cf977',1,'Zmogus::setName()'],['../class_student.html#a56f92191fed01e809ba2a57f92058adb',1,'Student::setName(const string &amp;vardas) override']]],
  ['setsinglegrade_5',['setSingleGrade',['../class_student.html#a0de678486a4c13dad36fb3087f3fcb02',1,'Student']]],
  ['setsurname_6',['setSurname',['../class_zmogus.html#ac06f7453d236aeef825126416b28ad55',1,'Zmogus::setSurname()'],['../class_student.html#a5b18ee52f8939e99d51fedaf7d55a041',1,'Student::setSurname()']]],
  ['shrink_5fto_5ffit_7',['shrink_to_fit',['../class_vector.html#ad6454ce193263b8000d4c18cb0c3a0c8',1,'Vector']]],
  ['size_8',['size',['../class_vector.html#a9e7e854146e2b56c2c7149eddbc0a1e8',1,'Vector']]],
  ['size_5ftype_9',['size_type',['../class_vector.html#a856845b26ace3be36885ca4f96c7727e',1,'Vector']]],
  ['skaiciuotividurki_10',['skaiciuotiVidurki',['../student_8h.html#a8f644a0421214bf8f70f8a5ed4e177ad',1,'student.cpp']]],
  ['student_11',['Student',['../class_student.html',1,'Student'],['../class_student.html#af9168cedbfa5565cf0b20c1a9d3f5c9d',1,'Student::Student()']]],
  ['student_2eh_12',['student.h',['../student_8h.html',1,'']]],
  ['surname_13',['surname',['../class_zmogus.html#a3c1523956681968e2f0ed0477d5ef2d6',1,'Zmogus']]],
  ['swap_14',['swap',['../class_vector.html#a49e40925d5cd8c16af79a5ae870dbfdd',1,'Vector']]]
];
