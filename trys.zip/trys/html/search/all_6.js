var searchData=
[
  ['generaterandomdata_0',['generateRandomData',['../student_8h.html#ab7b76d2722a314b8abe211dba4801e32',1,'student.cpp']]],
  ['generaterandomgrades_1',['generateRandomGrades',['../student_8h.html#aec582160987450a9e1f18af8e7f3fc7b',1,'student.cpp']]],
  ['generaterandomnumber_2',['generateRandomNumber',['../student_8h.html#a8738fde2cefb820cd40c39cd0862ad2c',1,'student.cpp']]],
  ['getexamresult_3',['getExamResult',['../class_student.html#a700fc566d4c6eb5edab6d278621204a3',1,'Student']]],
  ['getfinalavg_4',['getFinalAvg',['../class_student.html#a0f38908b6988e47f3c28d297459db3a3',1,'Student']]],
  ['getfinalmedian_5',['getFinalMedian',['../class_student.html#afd57f79f99ff9f35ecd3692eff118b46',1,'Student']]],
  ['getgrades_6',['getGrades',['../class_student.html#a4a2c255ecbf5645d1703b5a3101d13ed',1,'Student']]],
  ['getname_7',['getName',['../class_zmogus.html#a94f1670c7539cdaf4fa93cd8ccfc30f6',1,'Zmogus::getName()'],['../class_student.html#a2249ce4a1cc43d2a287351b43586190c',1,'Student::getName() const override']]],
  ['getsinglegrade_8',['getSingleGrade',['../class_student.html#ab6feb127b11eda23a5bb5690a25d1de3',1,'Student']]],
  ['getsurname_9',['getSurname',['../class_zmogus.html#a86d0927f1406c0668d46d5822a8658af',1,'Zmogus::getSurname()'],['../class_student.html#a847776f743684c63115c7f28828646ac',1,'Student::getSurname()']]]
];
