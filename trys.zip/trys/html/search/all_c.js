var searchData=
[
  ['pop_5fback_0',['pop_back',['../class_vector.html#adcba035109febbe55cba2a25f8483ba6',1,'Vector']]],
  ['push_5fback_1',['push_back',['../class_vector.html#a230478d31727b508dcb92a66e786f891',1,'Vector::push_back(const value_type &amp;t)'],['../class_vector.html#aa2dd3eeac2c6070bd7cb7378a3784e3f',1,'Vector::push_back(value_type &amp;&amp;val)']]]
];
