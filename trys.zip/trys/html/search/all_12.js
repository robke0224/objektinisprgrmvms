var searchData=
[
  ['_7estudent_0',['~Student',['../class_student.html#a54a8ea060d6cd04222c3a2f89829f105',1,'Student']]],
  ['_7evector_1',['~Vector',['../class_vector.html#afd524fac19e6d3d69db5198ffe2952b0',1,'Vector']]],
  ['_7ezmogus_2',['~Zmogus',['../class_zmogus.html#ac5615bf607a8f2f1b303ffa04328d24d',1,'Zmogus']]]
];
