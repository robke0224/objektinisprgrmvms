var searchData=
[
  ['name_0',['name',['../class_zmogus.html#a07bbe3ec35694144ecca725959cfaa44',1,'Zmogus']]],
  ['nuskaitymas_1',['Nuskaitymas',['../student_8h.html#a3fef6b0b89373ffccafd02494c7ac67d',1,'student.cpp']]]
];
