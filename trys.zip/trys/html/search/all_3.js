var searchData=
[
  ['dabartinislaikas_0',['DabartinisLaikas',['../student_8h.html#a2755e0e3fa21ebdf15a5e7bb8b3ea3d5',1,'student.cpp']]],
  ['data_1',['data',['../class_vector.html#ae153d7d061e5d4c5e8b857bccdc3d92f',1,'Vector::data() noexcept'],['../class_vector.html#a7a0a30580df4155cd793623ee50ddf50',1,'Vector::data() const noexcept']]]
];
