var searchData=
[
  ['laikoskirtumas_0',['LaikoSkirtumas',['../student_8h.html#a9225ccbe3712e7920e03c6200ad6c064',1,'student.cpp']]],
  ['lygintipagalvidurki_1',['lygintiPagalVidurki',['../student_8h.html#a54e7f31d30437d86acf6195e93fb1d04',1,'student.cpp']]]
];
